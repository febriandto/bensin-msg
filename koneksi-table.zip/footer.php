    <section id="footer">
      <footer class="text-center bg-danger">
        <!-- <a href="https://time.is/Jakarta" id="time_is_link" rel="nofollow" style="font-size:15px; color: black;"></a>
        <span id="Jakarta_z41c" style="font-size:15px;"></span>
        <script src="//widget.time.is/en.js"></script>
        <script>
        time_is_widget.init({Jakarta_z41c:{template:"TIME \| DATE", date_format:"daynum-monthnum-year"}});
        </script> -->&copy; MSG 2018 Allrights Reseved
        <!-- Designed & Develop by Febri -->
      </footer>
    </section>
    <script src="js/script.js?v=<?php echo time(); ?>"></script>
  </body>
</html>
<?php 
include "header.php"; 
?>
<br>
<h1 class="text-center">Profile</h1>
<br>
<div class="container">
	<div class="row">
		<div class="col text-center">
			<img src="img/bg.jpg" alt="" width="200">
		</div>
	</div>

	<div class="row">
		<div class="col">
			<div id="profile">
				<table class="table">
					<tr>
						<ul>
							<li><p>Nama Pelanggan: Cibonteng</p></li>
							<li><p>Mesin: Digital</p></li>
							<li><p>Setoran: Rp.86700</p></li>
							<li><p>Jenis Bensin: Pertalite</p></li>
							<li><p>Contact: 08318281812</p></li>
						</ul>			
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>

<?php include "footer.php"; ?>